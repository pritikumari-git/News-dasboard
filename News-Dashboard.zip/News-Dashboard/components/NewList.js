import { useAppContext } from '../context/AppContext';

const NewsList = () => {
  const { articles, filters } = useAppContext();
  const filtered = articles.filter(
    (a) =>
      (!filters.author || a.author.includes(filters.author)) &&
      (!filters.type || a.type === filters.type) &&
      (!filters.date || a.date.startsWith(filters.date))
  );

  return (
    <div>
      {filtered.map((a) => (
        <div key={a.id} className="p-2 border-b">
          <h3>{a.title}</h3>
          <p>{a.author} - {new Date(a.date).toLocaleDateString()} - {a.type}</p>
        </div>
      ))}
    </div>
  );
};

export default NewsList;