import { useAppContext } from '../context/AppContext';
import { login } from '../lib/auth';
import { useState } from 'react';

const AuthProvider = () => {
  const { setUser } = useAppContext();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    const userData = login(email, password);
    setUser(userData);
  };

  return (
    <div className="p-4">
      <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="input" />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className="input" />
      <button onClick={handleLogin} className="btn">Login</button>
    </div>
  );
};

export default AuthProvider;
