import { exportPDF, exportCSV } from '../lib/export';
import { useAppContext } from '../context/AppContext';

const ExportButtons = () => {
  const { articles, payoutRate } = useAppContext();
  const counts = {};
  articles.forEach((a) => (counts[a.author] = (counts[a.author] || 0) + 1));
  const data = Object.keys(counts).map((author) => ({
    author,
    count: counts[author],
    payout: counts[author] * payoutRate
  }));

  return (
    <div className="mt-4">
      <button onClick={() => exportPDF(data)} className="btn">Export PDF</button>
      <button onClick={() => exportCSV(data)} className="btn ml-2">Export CSV</button>
    </div>
  );
};

export default ExportButtons;
