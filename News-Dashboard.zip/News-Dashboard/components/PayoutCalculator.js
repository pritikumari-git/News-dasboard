import { useAppContext } from '../context/AppContext';

const PayoutCalculator = () => {
  const { articles, payoutRate, setPayoutRate } = useAppContext();
  const counts = {};

  articles.forEach((a) => {
    counts[a.author] = (counts[a.author] || 0) + 1;
  });

  const data = Object.keys(counts).map((author) => ({
    author,
    count: counts[author],
    payout: counts[author] * payoutRate
  }));

  return (
    <div>
      <input type="number" value={payoutRate} onChange={(e) => setPayoutRate(Number(e.target.value))} className="input" />
      <table className="table-auto w-full">
        <thead><tr><th>Author</th><th>Articles</th><th>Payout</th></tr></thead>
        <tbody>
          {data.map((d) => (
            <tr key={d.author}><td>{d.author}</td><td>{d.count}</td><td>₹{d.payout}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PayoutCalculator;
