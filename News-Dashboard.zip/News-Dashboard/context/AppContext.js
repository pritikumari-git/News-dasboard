import { createContext, useContext, useState, useEffect } from 'react';

const AppContext = createContext();
export const useAppContext = () => useContext(AppContext);

export const AppProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [articles, setArticles] = useState([]);
  const [filters, setFilters] = useState({ author: '', date: '', type: '' });
  const [payoutRate, setPayoutRate] = useState(() => {
    return JSON.parse(localStorage.getItem('payoutRate')) || 0;
  });

  useEffect(() => {
    localStorage.setItem('payoutRate', JSON.stringify(payoutRate));
  }, [payoutRate]);

  return (
    <AppContext.Provider
      value={{ user, setUser, articles, setArticles, filters, setFilters, payoutRate, setPayoutRate }}
    >
      {children}
    </AppContext.Provider>
  );
};