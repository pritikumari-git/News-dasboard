import { useAppContext } from '../context/AppContext';
import PayoutCalculator from '../components/PayoutCalculator';
import ExportButtons from '../components/ExportButtons';

const Admin = () => {
  const { user } = useAppContext();
  if (!user || user.role !== 'admin') return <div>Unauthorized</div>;

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Admin Dashboard</h2>
      <PayoutCalculator />
      <ExportButtons />
    </div>
  );
};

export default Admin;
