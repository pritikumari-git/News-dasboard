import { useEffect } from 'react';
import AuthProvider from '../components/AuthProvider';
import NewsList from '../components/NewsList';
import { useAppContext } from '../context/AppContext';
import { fetchNewsData } from '../lib/api';

export default function Home() {
  const { articles, setArticles, user } = useAppContext();

  useEffect(() => {
    fetchNewsData().then(setArticles);
  }, []);

  if (!user) return <AuthProvider />;

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">News Dashboard</h1>
      <NewsList />
    </div>
  );
}